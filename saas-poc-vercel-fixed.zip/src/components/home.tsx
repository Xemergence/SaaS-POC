import { Navigate } from "react-router-dom";

function Home() {
  return <Navigate to="/dashboard" replace />;
}

export default Home;
